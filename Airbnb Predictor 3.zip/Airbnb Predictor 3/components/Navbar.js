// components/Navbar.js
import React from 'react';
import { AppBar, Toolbar, Typography, Button, Box, IconButton } from '@mui/material';
import Image from 'next/image';
import { Brightness4, Brightness7 } from '@mui/icons-material';
import { useColorMode } from '../theme';
import Link from 'next/link';

export default function Navbar() {
  const { toggleColorMode, mode } = useColorMode();

  return (
    <AppBar position="static" sx={{ backgroundColor: '#FF385C' }}> {/* Airbnb pink/orange color */}
      <Toolbar>
        <Typography variant="h6" sx={{ flexGrow: 1 }}>
            <Image src="/logo.png" alt="Airbnb Predictor" width={40} height={40} style={{ marginRight: 8 }} />
        </Typography>
        <Box>
          <Button color="inherit" component={Link} href="/">
            Accueil
          </Button>
          <Button color="inherit" component={Link} href="/form">
            Formulaire
          </Button>
          <IconButton onClick={toggleColorMode} color="inherit" sx={{ ml: 2 }}>
            {mode === 'light' ? <Brightness7 /> : <Brightness4 />}
          </IconButton>
        </Box>
      </Toolbar>
    </AppBar>
  );
}
