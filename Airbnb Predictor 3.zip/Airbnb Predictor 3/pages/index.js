import React from 'react';
import { Typography, Button, Container, Box } from '@mui/material';

export default function Home() {

  return (
    <Container maxWidth="lg">
      <Box textAlign="center" py={10}>
        <Typography variant="h2" gutterBottom>
          Bienvenue sur Airbnb Predictor
        </Typography>
        <Typography variant="h5" color="textSecondary" paragraph>
          Notre intelligence artificielle analyse vos annonces Airbnb pour déterminer si elles sont de bonnes affaires.
          Optimisez vos réservations dès aujourd'hui !
Vous cherchez à savoir si votre logement correspond aux attentes des voyageurs ? Notre application vous aide à analyser vos annonces Airbnb en fonction des critères essentiels : localisation, prix, équipements, et bien plus. Grâce à notre outil intuitif, obtenez des conseils personnalisés pour attirer plus de voyageurs et maximiser vos réservations.''
        </Typography>
        <Button
          variant="contained"
          color="primary"
          size="large"
          href="/form"
          sx={{ mt: 4 }}
        >
          Commencer maintenant
        </Button>
      </Box>
    </Container>
  );
}