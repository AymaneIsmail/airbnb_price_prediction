import React from 'react';
import { ThemeConfig } from '../theme';
import Navbar from '../components/Navbar';

export default function App({ Component, pageProps }) {
  return (
    <ThemeConfig>
      <Navbar />
      <Component {...pageProps} />
    </ThemeConfig>
  );
}