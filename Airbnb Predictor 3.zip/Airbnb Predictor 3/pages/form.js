// pages/form.js
import React, { useState } from 'react';
import {
  Container,
  TextField,
  Button,
  Typography,
  Box,
  Paper,
} from '@mui/material';

export default function FormPage() {
  const [formData, setFormData] = useState({
    neighbourhood_cleansed: '',
    room_type: '',
    accommodates: '',
    bathrooms: '',
    beds: '',
    number_of_reviews_ltm: '',
    review_scores_rating: '',
    bedrooms: '',
    amenities_count: '',
    price_per_person: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    alert('Données soumises :\n' + JSON.stringify(formData, null, 2));
  };

  return (
    <Container maxWidth="sm">
      <Box py={5}>
        <Paper elevation={3} sx={{ p: 4 }}>
          <Box textAlign="center" mb={3}>
            <img src="/logo.png" alt="Airbnb Predictor Logo" style={{ height: 80 }} />
          </Box>
          <Typography variant="h4" gutterBottom textAlign="center">
            Formulaire de Prédiction Airbnb
          </Typography>
          <Typography
            variant="body1"
            color="textSecondary"
            paragraph
            textAlign="center"
          >
            
          </Typography>
          <form onSubmit={handleSubmit}>
            <Box display="flex" flexDirection="column" gap={3}>
              <TextField
                fullWidth
                label="Quartier"
                name="neighbourhood_cleansed"
                value={formData.neighbourhood_cleansed}
                onChange={handleChange}
                variant="outlined"
              />
              <TextField
                fullWidth
                label="Type de chambre"
                name="room_type"
                value={formData.room_type}
                onChange={handleChange}
                variant="outlined"
              />
              <TextField
                fullWidth
                type="number"
                label="Nombre d'accommodations"
                name="accommodates"
                value={formData.accommodates}
                onChange={handleChange}
                variant="outlined"
              />
              <TextField
                fullWidth
                type="number"
                label="Nombre de salles de bain"
                name="bathrooms"
                value={formData.bathrooms}
                onChange={handleChange}
                variant="outlined"
              />
              <TextField
                fullWidth
                type="number"
                label="Nombre de lits"
                name="beds"
                value={formData.beds}
                onChange={handleChange}
                variant="outlined"
              />
              <TextField
                fullWidth
                type="number"
                label="Nombre d'avis récents"
                name="number_of_reviews_ltm"
                value={formData.number_of_reviews_ltm}
                onChange={handleChange}
                variant="outlined"
              />
              <TextField
                fullWidth
                type="number"
                label="Score des avis"
                name="review_scores_rating"
                value={formData.review_scores_rating}
                onChange={handleChange}
                variant="outlined"
              />
              <TextField
                fullWidth
                type="number"
                label="Nombre de chambres"
                name="bedrooms"
                value={formData.bedrooms}
                onChange={handleChange}
                variant="outlined"
              />
              <TextField
                fullWidth
                type="number"
                label="Nombre d'équipements"
                name="amenities_count"
                value={formData.amenities_count}
                onChange={handleChange}
                variant="outlined"
              />
              <TextField
                fullWidth
                type="number"
                label="Prix par personne (€)"
                name="price_per_person"
                value={formData.price_per_person}
                onChange={handleChange}
                variant="outlined"
              />
              <Button type="submit" variant="contained" color="primary" size="large">
                Obtenir une prédiction
              </Button>
            </Box>
          </form>
        </Paper>
      </Box>
    </Container>
  );
}
