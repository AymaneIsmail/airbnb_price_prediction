const CHUNK_PUBLIC_PATH = "server/pages/form.js";
const runtime = require("../chunks/ssr/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/ssr/node_modules_next_91ecbf._.js");
runtime.loadChunk("server/chunks/ssr/node_modules_@mui_material_abaf63._.js");
runtime.loadChunk("server/chunks/ssr/node_modules_@mui_system_b3f7ad._.js");
runtime.loadChunk("server/chunks/ssr/node_modules_0b48ee._.js");
runtime.loadChunk("server/chunks/ssr/[root of the server]__8097c5._.js");
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/pages/form.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/pages/_app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
