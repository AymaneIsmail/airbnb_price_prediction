const CHUNK_PUBLIC_PATH = "server/pages/_error.js";
const runtime = require("../chunks/ssr/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/ssr/node_modules_next_679254._.js");
runtime.loadChunk("server/chunks/ssr/node_modules_@mui_material_9f819e._.js");
runtime.loadChunk("server/chunks/ssr/node_modules_@mui_system_3d8bfb._.js");
runtime.loadChunk("server/chunks/ssr/node_modules_268a87._.js");
runtime.loadChunk("server/chunks/ssr/[root of the server]__bf4e74._.js");
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/node_modules/next/error.js [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/node_modules/next/document.js [ssr] (ecmascript)\", INNER_APP => \"[project]/pages/_app.js [ssr] (ecmascript)\" } [ssr] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
