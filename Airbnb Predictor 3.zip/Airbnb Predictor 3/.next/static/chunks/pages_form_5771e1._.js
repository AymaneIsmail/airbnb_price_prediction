(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages_form_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages_form_5771e1._.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_b8496e._.js",
    "static/chunks/node_modules_react-dom_82bb97._.js",
    "static/chunks/node_modules_@mui_system_de2209._.js",
    "static/chunks/node_modules_@mui_material_79b145._.js",
    "static/chunks/node_modules_0196f0._.js",
    "static/chunks/[root of the server]__017e41._.js"
  ],
  "source": "entry"
});
