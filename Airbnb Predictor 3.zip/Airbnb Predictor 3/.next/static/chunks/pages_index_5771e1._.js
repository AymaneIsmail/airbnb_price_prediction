(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages_index_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages_index_5771e1._.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_b8496e._.js",
    "static/chunks/node_modules_react-dom_82bb97._.js",
    "static/chunks/node_modules_@mui_system_357030._.js",
    "static/chunks/node_modules_@mui_material_dcd1ad._.js",
    "static/chunks/node_modules_c22475._.js",
    "static/chunks/[root of the server]__13f17c._.js"
  ],
  "source": "entry"
});
