(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/pages__app_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/pages__app_5771e1._.js",
  "chunks": [
    "static/chunks/node_modules_next_5737bb._.js",
    "static/chunks/node_modules_react-dom_82bb97._.js",
    "static/chunks/node_modules_@mui_material_e34f88._.js",
    "static/chunks/node_modules_@mui_system_5ddd12._.js",
    "static/chunks/node_modules_2f2243._.js",
    "static/chunks/[root of the server]__d46fdd._.js"
  ],
  "source": "entry"
});
