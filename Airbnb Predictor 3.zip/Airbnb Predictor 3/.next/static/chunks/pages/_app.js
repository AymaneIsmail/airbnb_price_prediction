__turbopack_load_page_chunks__("/_app", [
  "static/chunks/node_modules_next_5737bb._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_@mui_material_e34f88._.js",
  "static/chunks/node_modules_@mui_system_5ddd12._.js",
  "static/chunks/node_modules_2f2243._.js",
  "static/chunks/[root of the server]__d46fdd._.js",
  "static/chunks/pages__app_5771e1._.js",
  "static/chunks/pages__app_aee6ef._.js"
])
