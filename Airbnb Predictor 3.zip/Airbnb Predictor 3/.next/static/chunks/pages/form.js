__turbopack_load_page_chunks__("/form", [
  "static/chunks/node_modules_next_dist_b8496e._.js",
  "static/chunks/node_modules_react-dom_82bb97._.js",
  "static/chunks/node_modules_@mui_system_de2209._.js",
  "static/chunks/node_modules_@mui_material_79b145._.js",
  "static/chunks/node_modules_0196f0._.js",
  "static/chunks/[root of the server]__017e41._.js",
  "static/chunks/pages_form_5771e1._.js",
  "static/chunks/pages_form_23af94._.js"
])
